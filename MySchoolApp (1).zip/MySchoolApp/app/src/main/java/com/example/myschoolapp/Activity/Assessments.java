package com.example.myschoolapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Assessment;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/
public class Assessments extends AppCompatActivity {
    Button cancelTestBtn, addTestsBTT;

    // need to add a repository for the recylcerview on this page
    Repository repository;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessments);

        addTestsBTT = findViewById(R.id.addAssessmentTestBTT);

        addTestsBTT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToTestDetails = new Intent(Assessments.this, AssessmentDetailPage.class);


                Toast.makeText(Assessments.this,
                        // test to make sure it go to the page
                        "Going to assessment detail page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToTestDetails);

            }
        });
        /***
         ** - 1. having Cancel Button go Back to main Page
         */
        // need to go back to the main page after Canceling
      cancelTestBtn = findViewById(R.id.cancelTestsBTT);
        cancelTestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackFromTests = new Intent(Assessments.this,MainActivity.class);
                {
                    Toast.makeText(Assessments.this,
                            // test to make sure it go to the page
                            "Canceling Request",
                            Toast.LENGTH_SHORT).show();
                    startActivity(goBackFromTests);
                }
            }
        });


        /***
         ** 2. need to create the recycler view and populate it
         ** - will query the database or put something on it
         ** - adding with the getAll
         ** - need to call the tests adapter
         ** - need to set the recycler view to the adapter
         ** - layout manager needs to be set to recyclerView
         ** - using the set adapter method to bring items onto list
         */

        RecyclerView testRecyclerView = findViewById(R.id.testListRecyclerView);

        // querying the database
        repository = new Repository(getApplication());

        //  need to get it from the repository and put it on the list
        List<Assessment> allAvailableTests = repository.getmAllTests();

        // testAdapter
        final AssessmentsAdapter assessmentsAdapter = new AssessmentsAdapter(this);

        // setting on the recyclerView
        testRecyclerView.setAdapter(assessmentsAdapter);

        // layout view to recycler view
        testRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // adapter.set method
       assessmentsAdapter.setTests(allAvailableTests);









    }


    /****
     *** end of the line
     *** don't continue
     **/
    /*+=!^^^!=++=!^^^!=+  REQUIREMENTS    +=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=+
    - need to send alerts for the beginning and end


    +=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=++=!^^^!=+
  */
}