package com.example.myschoolapp.Database;

import android.app.Application;

import com.example.myschoolapp.DAO.AssessmentDAO;
import com.example.myschoolapp.DAO.CourseDAO;
import com.example.myschoolapp.DAO.TermDAO;
import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Course;
import com.example.myschoolapp.entities.Term;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    private CourseDAO mCourseDAO;
    private TermDAO mTermDAO;
    private AssessmentDAO mAssessmentDAO;

    private List<Term> mAllTerms;
    private List <Course> mAllCourses;
    private List<Assessment> mAllTests;


    private static int NUMBER_OF_THREADS =4;
    static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public Repository(List<Term> mAllTerms, List<Course> mAllCourses, List<Assessment> mAllTests) {
        this.mAllTerms = mAllTerms;
        this.mAllCourses = mAllCourses;
        this.mAllTests = mAllTests;
    }

  public Repository(Application application){
        MySchoolAppDatabaseBuilder databaseBuilder = MySchoolAppDatabaseBuilder.getDatabase(application);
        mTermDAO = databaseBuilder.termDAO();
        mCourseDAO = databaseBuilder.courseDAO();
        mAssessmentDAO = databaseBuilder.assessmentDAO();
  }

    // get all Methods
    public List<Term> getmAllTerms(){
        databaseExecutor.execute(()->{
            mAllTerms = mTermDAO.getAllTerms();
        });

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return mAllTerms;
    }

    public List<Course> getmAllCourses(){
        databaseExecutor.execute(()->{
            mAllCourses = mCourseDAO.getAllCourses();
        });
        try{
            Thread.sleep(100);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
        return mAllCourses;
    }





    public List<Assessment> getmAllTests(){
        databaseExecutor.execute(()->{
            mAllTests = mAssessmentDAO.getAllAssessments();
        });
        try {
            Thread.sleep(100);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        return mAllTests;
    }

    //insert methods
    // term
    public void insertTerm(Term term){
        databaseExecutor.execute(()-> mTermDAO.insertTerm(term));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    // course
    public void insertCourse(Course course){
        databaseExecutor.execute(()-> mCourseDAO.insertCourse(course));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    // test
    public void insertTest(Assessment assessment){
        databaseExecutor.execute(()-> mAssessmentDAO.insertTest(assessment));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    //delete methods
    //course
   public void deleteCourse(Course course){
        databaseExecutor.execute(()->mCourseDAO.deleteCourse(course));
        try{
            Thread.sleep(100);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
   }

    //test
    public void deleteTest(Assessment assessment){
        databaseExecutor.execute(()->mAssessmentDAO.deleteTest(assessment));
        try{
            Thread.sleep(100);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    //term
    public void deleteTerm(Term term){
        databaseExecutor.execute(()->mTermDAO.deleteTerm(term));
        try{
            Thread.sleep(100);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }


    // update methods
    // test
    public void updateTest(Assessment assessment){
        databaseExecutor.execute(()-> mAssessmentDAO.updateTest(assessment));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    // term
    public void updateTerm(Term term){
        databaseExecutor.execute(()-> mTermDAO.updateTerm(term));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    //course
    // test
    public void updateCourse(Course course){
        databaseExecutor.execute(()-> mCourseDAO.updateCourse(course));
        try{
            Thread.sleep(100);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }


}
