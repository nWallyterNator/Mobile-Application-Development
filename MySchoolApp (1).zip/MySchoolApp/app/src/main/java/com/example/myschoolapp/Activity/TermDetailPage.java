package com.example.myschoolapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Course;
import com.example.myschoolapp.entities.Term;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/****
 *** @author Nicholas Walters
 **/
public class TermDetailPage extends AppCompatActivity {

//    /***
//     ** - 1. need a recyclcyerView to add the associated courses
//     */
//    RecyclerView courseWithTerm;



    // 2 visible buttons, save term and cancel button
    Button saveTermBtn, cancelBtn;
    // making the repository to test it
    // this repository will go in the options button

    // need the current term from the list to delete
    Term crntTerm;

    // need the current number of courses for the delete to see if anything is attached to it
    int numberOfCouresAttached;

    Repository repository;
    // need a termId
    int termID;


    // need a term
    Term term;

//    // adding a calendar for start
//    Calendar termStartCalender = Calendar.getInstance();


//    // adding a calendar for end
//    Calendar termEndCalender = Calendar.getInstance();


    /***
     ** 3. - adding things from the edit text part of the file
     ** -  there are 3 edit texts, name, begin and end date
     ** - section off begin and end date so that I can see it and will change it
     */
    // term name
    EditText changeTermName;


//    // begin date change after I do date picker
//    TextView changeTermStartDate;
//
//
//    // end date change after I do date picker
//    TextView changeTermEndDate;
    /***
     ** 5. - can't get the dates to save trying again from the begining
     ** - need the textViews for the date
     ** - need datepickerdialogs
     ** - need calenders
     ** - Strings for end and begin
     */
    // textViews
    TextView changeBegDateForTerm, changeEndDateForTerm;

    // datepickerDialogs
    DatePickerDialog.OnDateSetListener beginTermDate, endTermDate;

    //Calenders
    final Calendar termStartCalendar = Calendar.getInstance();
    final Calendar termEndCalendar = Calendar.getInstance();

    // strings for start and begin date
    String startingTermDate, endingTermDate;




    /***
     ** 4. - senders for the recylcer view
     ** - need 3, term Name, begining date, end date
     ** - change beginning date, end date
     */
    // sending termName
    String termName;

//    //string for begin term date and end date
//    String beginTermDate, endTermDate;


//    // sending term begin date leave space to change
//    // isn't a string instead its a DatePickerDialog.OnDateSetListener
////    String termStartDate;
//    DatePickerDialog.OnDateSetListener termStartDate;
//
//
//    // sending term end date leave space to change
//    DatePickerDialog.OnDateSetListener termEndDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_detail_page);



        /***
         ** 6. - trying recyclerView because it wasn't populating before
         ** - course adapter
         ** - need the recylerview
         ** - need a list
         */
//        //course adapter
//        final CoursesAdapter coursesAdapter = new CoursesAdapter(this);
//


//        // recyclerView
//        RecyclerView recyclerViewWithCourses = findViewById(R.id.courseWithTerm);
//
//        recyclerViewWithCourses.setAdapter(coursesAdapter);
//
//        recyclerViewWithCourses.setLayoutManager(new LinearLayoutManager(this));

//        // list = assCourses
//        List<Course> assCourses = new ArrayList<>();
//        // for loop to get all the courses
//        for(Course c1 :repository.getmAllCourses()){
//            if(c1.getTermID()==termID)assCourses.add(c1);
//        }
//        coursesAdapter.setCourses(assCourses);


        /********* RecyclcerView*/
        // need id
//       RecyclerView courseWithTerm = findViewById(R.id.recyclerViewForTermDetails);
//
//       courseWithTerm.setAdapter(coursesAdapter);
//
//       courseWithTerm.setLayoutManager(new LinearLayoutManager(this));
//
//        // need to get the termID
//        termID = getIntent().getIntExtra("termID", -1);
//        // need the repository
//        repository = new Repository(getApplication());
//
//        // need the adapter
//        final CoursesAdapter coursesAdapter1 = new CoursesAdapter(this);
//
//        // need to set the recyclcerview to the adapter
//        courseWithTerm.setAdapter(coursesAdapter1);
//
//        // need a layout manager
//        courseWithTerm.setLayoutManager(new LinearLayoutManager(this));

        // getting a list which will be the name of the associated courses
//        List<Course> assCourses = new ArrayList<>();
//
//        // for loop to get all the courses
//        for(Course assTermsAndCourses : repository.getmAllCourses()){
//            // this will filter out a specific course
//            // if it has the same id as the term and the course matches
//            // then it will add it to the associated list
//            if(assTermsAndCourses.getTermID() == termID) assCourses.add(assTermsAndCourses);
//        }
//        coursesAdapter.setCourses(assCourses);
//
//        // need to set the adapter to the associated list
//


        // adding format for date and adding a string
        String myFormatForCalendar = "MM/dd/yy";
        // adding SimpleDateFormat
        SimpleDateFormat sdf = new SimpleDateFormat(myFormatForCalendar, Locale.US);

        /***
         ** 5. need to initalize by finding by id there
         ** - going to use the getIntent to get the values
         ** - after getting it you do .set text method
         ** - commenting out to run it all on the main screen
         */


        //name text view
        changeTermName = findViewById(R.id.changeTermNameTvTermDetails);

        // term name from the getintent
        termName = getIntent().getStringExtra("name");

        // set text method
        changeTermName.setText(termName);

//
//        // Begin Date
//        // begin date text view - leave for space to change
//        changeTermStartDate = findViewById(R.id.changeTermStartDayTvTermDetails);
//        // the getIntent for term
//        beginTermDate = getIntent().getStringExtra("startingDate");
//        endTermDate = getIntent().getStringExtra("endingDate");

//        // if statement to eather get a new calender or set it
//        if(termID == -1){
//            changeTermStartDate.setText(sdf.format(new Date()) );
//            changeTermEndDate.setText(sdf.format(new Date()));
//        }
//        else{
//            changeTermEndDate.setText(endTermDate);
//            changeTermStartDate.setText(beginTermDate);
//        }


        // termStart date for getIntent
        // termStartDate gets set to a new OnDateSet Listener
//        termStartDate = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                //setting termStartCalender in year month day format
//                termStartCalender.set(Calendar.YEAR, year);
//
//                termStartCalender.set(Calendar.MONTH, month);
//
//                termStartCalender.set(Calendar.DAY_OF_MONTH, day);
//
//                updateStartingTermLabel();
//
//            }
//        };


//        termStartDate = getIntent().getStringExtra("startingDate");
//        // changeTermStartDate to setText to termStart
//        changeTermStartDate.setText(termStartDate);
        // changeTermStartDate setting to an onclickListener
//        changeTermStartDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Date startTermDateW;
//
//                String info = changeTermStartDate.getText().toString();
//
//                if (info.equals("")) info = "12/01/2023";
//
//                // try and catch statement
//                try {
//                    termStartCalender.setTime(sdf.parse(info));
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//                new DatePickerDialog(TermDetailPage.this, termStartDate,
//
//                        // adding year
//                        termStartCalender.get(Calendar.YEAR),
//                        // adding month
//                        termStartCalender.get(Calendar.MONTH),
//                        // adding day
//                        termStartCalender.get(Calendar.DAY_OF_MONTH)).show();
//
//            }
//        });
//
//
//        // End Date
//        // end date text view - leave to change
//        changeTermEndDate = findViewById(R.id.changeTermEndDayTvTermDetails);
//        //termEndDate gets set to a new OnDateSetListener
//        termEndDate = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//
//                // setting termEndCalender to year month day format
//                termEndCalender.set(Calendar.YEAR, year);
//
//                termEndCalender.set(Calendar.MONTH, month);
//
//                termEndCalender.set(Calendar.DAY_OF_MONTH, day);
//
//                // calling update method to change the label
//                updateEndingTermLabel();
//
//
//            }
//        };

//        //termEnd date for getIntent
//        termEndDate = getIntent().getStringExtra("endingDate");
//        changeTermEndDate.setText(termEndDate);
        // change termEndDate and set it to anONclick listener
//        changeTermEndDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Date termEndDateW;
//
//                String info = changeTermEndDate.getText().toString();
//
//                if (info.equals("")) info = "12/01/2023";
//
//                // try and catch statement
//                try {
//                    termEndCalender.setTime(sdf.parse(info));
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//                new DatePickerDialog(TermDetailPage.this, termEndDate,
//
//                        // adding year
//                        termEndCalender.get(Calendar.YEAR),
//                        // adding month
//                        termEndCalender.get(Calendar.MONTH),
//                        // adding day
//                        termEndCalender.get(Calendar.DAY_OF_MONTH)).show();
//
//
//            }
//        });


        // need to get a term ID
        termID = getIntent().getIntExtra("id", -1);

        // getMethod for new Calender
        /***
         ** 6. getting a new calendar and set method
         */
        //ids
        changeBegDateForTerm = findViewById(R.id.changeTermStartDayTvTermDetails);
        changeEndDateForTerm = findViewById(R.id.changeTermEndDayTvTermDetails);

        //getting the info from the strings from the adapter
        startingTermDate = getIntent().getStringExtra("startingDate");
        endingTermDate = getIntent().getStringExtra("endingDate");

        // setting info using an if statement if its at -1
        if (termID == -1) {
            changeBegDateForTerm.setText(sdf.format(new Date()));
            changeEndDateForTerm.setText(sdf.format(new Date()));
            // if it is found
            // else statement
        } else {
            changeEndDateForTerm.setText(endingTermDate);
            changeBegDateForTerm.setText(startingTermDate);
        }

        /***
         ** - start and end date making it a button
         */
        //start date
        changeBegDateForTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeBegDateForTerm.getText().toString();

                if (info.equals("")) info = "12/01/23";
                // try and catch statement
                try {
                    // calling the begin calendar
                    termStartCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog date picker
                new DatePickerDialog(TermDetailPage.this, beginTermDate,
                        termStartCalendar.get(Calendar.YEAR),
                        //month for calender
                        termStartCalendar.get(Calendar.MONTH),
                        // day of the month
                        termStartCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // end date button
        changeEndDateForTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeEndDateForTerm.getText().toString();

                if (info.equals("")) info = "12/01/23";
                //try and catch statement
                try {
                    //calling the end calender
                    termEndCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog datepicker
                new DatePickerDialog(TermDetailPage.this, endTermDate, termEndCalendar
                        .get(Calendar.YEAR),
                        //month
                        termEndCalendar.get(Calendar.MONTH),
                        // day
                        termEndCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // new end date new date picker dialog
        endTermDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year
                termEndCalendar.set(Calendar.YEAR, year);
                // month
                termEndCalendar.set(Calendar.MONTH, month);
                // day
                termEndCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update ending label
                updateEndingTermLabel();

            }


        };

        // new start date picker dialog
        beginTermDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year from the begin calendar
                termStartCalendar.set(Calendar.YEAR, year);
                // month
                termStartCalendar.set(Calendar.MONTH, month);
                // day
                termStartCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update start label method
                updateStartingTermLabel();

            }
        };


        /***
         ** - save button
         ** - need to do an if statement
         ** - doing an else statement
         ** - I want it to go back to the term list page after its done from saving
         */

//        saveTermBtn = findViewById(R.id.saveTermDetailsBTT);
//        //  the save button should save info and go back to the previous page
//        saveTermBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
////                // need to make sure that term id is found
////                if (termID == -1) {
////                    // if term isn't found create new term
////                    term = new Term(0, changeTermName.getText().toString(),
////                            changeBegDateForTerm.getText().toString(),
////                            changeEndDateForTerm.getText().toString());
////                    // need to insert the new term into the repository
////                    repository.insertTerm(term);
////
////                    // going back to the screen to refresh so we can see if it worked vs going back and forth
////                    Intent goBackWithSavedTerm = new Intent(TermDetailPage.this,
////                            Terms.class);
////                    startActivity(goBackWithSavedTerm);
////
////
////                }
////                // else if it is found then we will update the term
////                else {
////                    term = new Term(termID, changeTermName.getText().toString(),
////                            changeBegDateForTerm.getText().toString(),
////                            changeEndDateForTerm.getText().toString());
////                    // update term in repository
////                    repository.updateTerm(term);
////
////                    // going back to the screen to refresh so we can see if it worked vs going back and forth
////                    Intent goBackWithSavedTerm = new Intent(TermDetailPage.this,
////                            Terms.class);
////                    startActivity(goBackWithSavedTerm);
////                }
//
//
//                //
//
//
//            }
//        });
//
//
////        // recyclerView
////        RecyclerView recyclerView = findViewById(R.id.courseWithTerm);
////        // calling the course Adapter
////        CoursesAdapter courseAdapter = new CoursesAdapter(this);
////        recyclerView.setAdapter(courseAdapter);
////
////        // setlayout manager
////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
////        // course List
////        List<Course> separatedCourses = new ArrayList<>();
////
////        // for statement
////        for (Course course : repository.getmAllCourses()) {
////
////            // if it equals the term id then add it
////            if (course.getTermID() == termID) separatedCourses.add(course);
////        }
////
////        courseAdapter.setCourses(separatedCourses);
//
//
//        /***
//         ** - 2. going back to terms page
//         */
//        cancelBtn = findViewById(R.id.cancelGoBackToTermPage);
//        cancelBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Intent goBackToTerms = new Intent(TermDetailPage.this, Terms.class);
////
////                Toast.makeText(TermDetailPage.this,
////                        // test to make sure it go to the page
////                        "Canceling Request",
////                        Toast.LENGTH_SHORT).show();
////                startActivity(goBackToTerms);
//            }
//        });


        /***
         ** - 7. this if for the sample repository
         ** -  copying the code from the terms page
         */
        repository = new Repository(getApplication());




//        //  need to get it from the repository and put it on the list
//        List<Term> allAvailableTerms = repository.getmAllTerms();

//        // termAdapter
//        CoursesAdapter coursesAdapter = new CoursesAdapter(this);


        RecyclerView recyclerView = findViewById(R.id.recyclerViewForTermDetails);
        repository = new Repository(getApplication());
        // need course Adapter
        final CoursesAdapter coursesAdapter= new CoursesAdapter(this);
        recyclerView.setAdapter(coursesAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // new list for the filteredCourses
        List<Course> filteredCourses = new ArrayList<>();
        // for loop
        for(Course c: repository.getmAllCourses()){
            if(c.getTermID() == termID) filteredCourses.add(c);
        }
        coursesAdapter.setCourses(filteredCourses);
        /********************************/


    }


    /***
     ** - 4. making an option to create a course
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_term_detail_page, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {


        if (menuItem.getItemId() == R.id.deleteTermTermDetailsPageMenuItem) {
            // deleting a term

            // using a for each loop
            for (Term trm : repository.getmAllTerms()) {
                if (trm.getTermID() == termID) crntTerm = trm;
            }

            // need to check on if there are a number of courses attached
            numberOfCouresAttached = 0;

            // need to do another for loop need to know which courses are with each term
            for (Course course : repository.getmAllCourses()) {
                // if courses attached = to termId then increment
                if (course.getTermID() == termID) ++numberOfCouresAttached;
            }
            if (numberOfCouresAttached == 0) {
                // if there aren't any courses attached then you can delete
                repository.deleteTerm(crntTerm);
                // adding toast message to show which term got deleted
                Toast.makeText(TermDetailPage.this, crntTerm.getTermName() +
                        " was deleted from the list.", Toast.LENGTH_LONG).show();
                // going back to terms list
                Intent goBackToTermsScreen = new Intent(TermDetailPage.this, Terms.class);
                startActivity(goBackToTermsScreen);

            }

            // creating another toast message to say  that you can't delete a term with a course
            // attached to the term, delete the course first
            else {
                Toast.makeText(TermDetailPage.this,
                        "You can't delete the term. Please delete the associated course",
                        Toast.LENGTH_LONG).show();

                RecyclerView recyclerViewForTermDetails =findViewById(R.id.recyclerViewForTermDetails);
            }

        }


        if(menuItem.getItemId() == R.id.saveTermDetailsBTT ){
            // need to make sure that term id is found
            if (termID == -1) {
                // if term isn't found create new term
                term = new Term(0, changeTermName.getText().toString(),
                        changeBegDateForTerm.getText().toString(),
                        changeEndDateForTerm.getText().toString());
                // need to insert the new term into the repository
                repository.insertTerm(term);

                // going back to the screen to refresh so we can see if it worked vs going back and forth
                Intent goBackWithSavedTerm = new Intent(TermDetailPage.this,
                        Terms.class);
                startActivity(goBackWithSavedTerm);


            }
            // else if it is found then we will update the term
            else {
                term = new Term(termID, changeTermName.getText().toString(),
                        changeBegDateForTerm.getText().toString(),
                        changeEndDateForTerm.getText().toString());
                // update term in repository
                repository.updateTerm(term);

                // going back to the screen to refresh so we can see if it worked vs going back and forth
                Intent goBackWithSavedTerm = new Intent(TermDetailPage.this,
                        Terms.class);
                startActivity(goBackWithSavedTerm);
            }


        }

        if (menuItem.getItemId() == R.id.cancelTestDetailBTT){
            Intent goBackToTerms = new Intent(TermDetailPage.this, Terms.class);

            Toast.makeText(TermDetailPage.this,
                    // test to make sure it go to the page
                    "Canceling Request",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToTerms);
        }


        return true;
    }




    /*$%^^%$$%^^%$ $%^^%$    METHODS    $%^^%$ $%^^%$ $%^^%$ $%^^%$

    $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ */

    private void updateEndingTermLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeEndDateForTerm.setText(sdf.format(termEndCalendar.getTime()));


    }

    private void updateStartingTermLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeBegDateForTerm.setText(sdf.format(termStartCalendar.getTime()));
    }


    /****
     *** end of the line
     *** don't continue
     **/

    /*$%^^%$$%^^%$ $%^^%$    REQUIREMENTS    $%^^%$ $%^^%$ $%^^%$ $%^^%$
    - need to be able add as many terms as I can
    - display a list that goes along with each course
    - need to be delete, add, and update

    $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ $%^^%$ */

}