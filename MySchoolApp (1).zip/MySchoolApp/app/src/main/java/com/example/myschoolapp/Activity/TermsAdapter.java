package com.example.myschoolapp.Activity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Term;

import java.util.List;

public class TermsAdapter extends RecyclerView.Adapter<TermsAdapter.TermsViewHolder> {
    /***
     ** - 3. create the list of terms up top
     */
    private List<Term> mTerms;

    /***
     ** - declaring the context
     */
    private final Context context;

    /***
     ** - declaring the inflater
     */
    private final LayoutInflater mInflater;


    /***
     ** 1. - ViewHolder
     */
    public class TermsViewHolder extends RecyclerView.ViewHolder {
        private final TextView termItemListView;

        /***
         ** - initialize it in the constructor
         */
        public TermsViewHolder(@NonNull View itemView) {
            super(itemView);

            termItemListView = itemView.findViewById(R.id.textViewTermItemList);
            termItemListView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int termPosition = getAdapterPosition();
                    final Term currentTerm = mTerms.get(termPosition); // adding a method get the item from the list

                    // need to go to the screen
                    Intent goToTermDetailPageBridge = new Intent(context, TermDetailPage.class);


                    /***
                     ** - 7. need to use the putExtra method
                     ** - we need term id, term name, term start and end dates
                     ** - need to go to the next screen or start the activity after
                     */

                    //id
                    goToTermDetailPageBridge.putExtra("id",currentTerm.getTermID());
                    //name
                    goToTermDetailPageBridge.putExtra("name",currentTerm.getTermName());


                    // begin date - this will change with date picker
                    goToTermDetailPageBridge.putExtra("startingDate", currentTerm.getStartTermDay());

                    // end date -  this will change with date picker
                    goToTermDetailPageBridge.putExtra("endingDate", currentTerm.getEndTermDay());

                    // going to next activity
                    context.startActivity(goToTermDetailPageBridge);



                }
            });


        }
    }




    /***
     ** - 6. onCreateViewHolder
     ** - need to inflate
     */
    @NonNull
    @Override
    public TermsAdapter.TermsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.terms__item_layout,
                parent, false);



        // need to return the viewHolder
        return  new TermsViewHolder(itemView);



    }


    /***
     ** 8. - this is where we will display where we want to put it on the recylcer view
     ** - can't be null, using if
     */
    @Override
    public void onBindViewHolder(@NonNull TermsAdapter.TermsViewHolder holder, int position) {

        if(mTerms != null){
            Term currentTermForBindView = mTerms.get(position);
            String nameToFind = currentTermForBindView.getTermName();
            holder.termItemListView.setText(nameToFind);
        }
        else{
            holder.termItemListView.setText("No Term Found");
        }





    }








    /***
     ** 4. - getItem method
     **  - need to change return from 0 to mTerms
     **   -  making it an if else statement so that it won't crash
     */
    @Override
    public int getItemCount() {
        if (mTerms != null) {
            return mTerms.size();
        } else
            return 0;
    }


    /***
     ** 2. - method for setting the list
     */

    public void setTerms(List<Term> terms) {
        mTerms = terms;
        notifyDataSetChanged();
    }


    /***
     ** 5. - method for the inflator
     */
    public TermsAdapter(Context context){
        mInflater = LayoutInflater.from(context);
        this.context = context;

    }

}
