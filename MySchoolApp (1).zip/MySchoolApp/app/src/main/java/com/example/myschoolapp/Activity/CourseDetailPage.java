package com.example.myschoolapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Course;
import com.example.myschoolapp.entities.Term;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CourseDetailPage extends AppCompatActivity {

    List<Term> termsForSpinner;
    Repository repository;

    // need a course ID
    int courseID;
    /***
     ** - 1. couldn't get the start and end dates to work, commenting out
     ** - trying again
     ** - need textviews start and end, datepicker start and end,strings start and end,calendars start and end
     */
    //text View begin date and end date
    TextView changeBegDateForCourse, changeEndDateForCourse;
    // datepicker start and end
    DatePickerDialog.OnDateSetListener beginCourseDate, endCourseDate;
    // strings start and end
    String startingCourseDate, endingCourseDate;
    // calender start and end
    final Calendar courseStartCalendar = Calendar.getInstance();
    final Calendar courseEndCalendar = Calendar.getInstance();

    //


//    // adding a calendar for start
//    Calendar courseStartCalender = Calendar.getInstance();
//
//
//    // adding a calendar for end
//    Calendar courseEndCalender = Calendar.getInstance();

    /***
     ** - 2. need to do 7 things to declare
     ** - course name, start and end days,
     ** - instructor name, email and phone
     ** - course notes and course status
     ** - term id
     */
// course info
    // course name
    EditText changeCourseName;

    // need spinner for term
    Spinner spinner2;


//    // begin date needs to change due to date picker
//    // need to change the date to textView
//
//    TextView changeCourseBeginDate;
//
//
//    // end date same as above
//    TextView changeCourseEndDate;


    //instructors info

    // instructor name

    EditText changeTeacherName;

    // instructor email
    EditText changeTeachersEmail;

    // instructor phone
    EditText changeTeachersPhone;


    //random course info

    // course notes
    EditText changeCourseNote;


    // need a test Id
    int testID;

    //  need course object
    Course course;
    int termID;

    // need a crnt course to delete
    Course crntCrs;
    // need the current number of tests for the delete to see if anything is attached to it
    int numberOfTestsAttached;

    List<Term> terms;

    List<Course> allCourses;

    // need chosen term
    String chosenTerm;


    //Spinnner for courses
    // need string for courses
    Spinner courseStatusSpinner;
    String courseStatus;


    /***
     ** 3. - senders for the recylcer view
     ** - need 7, course Name, begining date, end date
     ** -  course name, start and end days,
     ** - instructor name, email and phone
     ** - course notes and course status
     ** - term id
     */

    //course name, begin date, end date
    String courseName;
//    // need DatePickerDialog
//    DatePickerDialog.OnDateSetListener courseStartDate;
//    //   tartDat courseSe,
//    DatePickerDialog.OnDateSetListener courseEndDate;

    // instructor name, email and phone
    String teacherName, teacherEmail, teacherPhone;

    // random notes and status
    String notes, status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail_page);
        /***
         ** 1. - term spinnner
         ** - need id
         ** - array list
         */
//        //id and cast
//


        /*********************************************** */
        //course Status Spinner
        // find the id
        courseStatusSpinner = findViewById(R.id.statusSpinner);

        // get the information
        courseStatus = getIntent().getStringExtra("courseStatus");

        // need array adapter
        ArrayAdapter<CharSequence> adapterCourseStatus = ArrayAdapter.createFromResource(this,
                R.array.status_list,
                android.R.layout.simple_spinner_dropdown_item);
        adapterCourseStatus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        courseStatusSpinner.setAdapter(adapterCourseStatus);

        repository = new Repository(getApplication());


        // need to make sure it isn't null
//        if (status != null) {
//            if (courseStatus.equals("Completed")) {
//                courseStatusSpinner.setSelection(0);
//            } else {
//                if (courseStatus.equals("In Progress")) {
//                    courseStatusSpinner.setSelection(1);
//                } else {
//                    if (courseStatus.equals("Dropped")) {
//                        courseStatusSpinner.setSelection(2);
//                    } else {
//                        courseStatusSpinner.setSelection(3);
//                    }
//                }
//            }
//        }
        if (courseID != -1) {
            int courseStatusPosition = adapterCourseStatus.getPosition(courseStatus);
            courseStatusSpinner.setSelection(courseStatusPosition);

        }

        /*********************************************** */


        /*****^%^%^%$%^$%^$%$%$%%$ term spinner */

        // need to call the id
        spinner2 = findViewById(R.id.spinner2);

        // will create a method to get a spinner
        // calling spinner
        createSpinner();


        // need to make the spinner clickable
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // getting a new term
                // getting i which is the position
                Term chosenTerm = terms.get(i);
                termID = chosenTerm.getTermID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /**%###$#$##$##########################$#%#$#%#%#$#$##%#%$#*/


        // adding format for date and adding a string
        String myFormatForCalendar = "MM/dd/yy";
        // adding SimpleDateFormat
        SimpleDateFormat sdf = new SimpleDateFormat(myFormatForCalendar, Locale.US);

        /***
         ** 4. - intializing by finding all of them from above
         ** - 7 are needed
         ** -  will do the getIntent method
         ** -  .setText method
         */
        // course name
        changeCourseName = findViewById(R.id.changeCourseNameTvCourseDetails);
        // getIntent for name
        courseName = getIntent().getStringExtra("name");
        // setText for name
        changeCourseName.setText(courseName);

        // getIntent for status
        status = getIntent().getStringExtra("courseStatus");

        /***
         ** 5. - need to get the dates
         */
        // finding ids - begindate
        changeBegDateForCourse = findViewById(R.id.changeCourseStartDayTvCourseDetails);
        changeEndDateForCourse = findViewById(R.id.changeCourseEndDayTvCourseDetails);

        //getting the info from the strings from the adapter
        startingCourseDate = getIntent().getStringExtra("beginDate");
        endingCourseDate = getIntent().getStringExtra("endDate");

        // setting info using an if statement if its at -1
        if (courseID == -1) {
            changeBegDateForCourse.setText(sdf.format(new Date()));
            changeEndDateForCourse.setText(sdf.format(new Date()));
            // if it is found
            // else statement
        } else {
            changeEndDateForCourse.setText(endingCourseDate);
            changeBegDateForCourse.setText(startingCourseDate);
        }

        /***
         ** - start and end date making it a button
         */
        //start date
        changeBegDateForCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeBegDateForCourse.getText().toString();

                if (info.equals("")) info = "12/01/23";
                // try and catch statement
                try {
                    // calling the begin calendar
                    courseStartCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog date picker
                new DatePickerDialog(CourseDetailPage.this, beginCourseDate,
                        courseStartCalendar.get(Calendar.YEAR),
                        //month for calender
                        courseStartCalendar.get(Calendar.MONTH),
                        // day of the month
                        courseStartCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // end date button
        changeEndDateForCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeEndDateForCourse.getText().toString();

                if (info.equals("")) info = "12/01/23";
                //try and catch statement
                try {
                    //calling the end calender
                    courseEndCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog datepicker
                new DatePickerDialog(CourseDetailPage.this, endCourseDate, courseEndCalendar
                        .get(Calendar.YEAR),
                        //month
                        courseEndCalendar.get(Calendar.MONTH),
                        // day
                        courseEndCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // new end date new date picker dialog
        endCourseDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year
                courseEndCalendar.set(Calendar.YEAR, year);
                // month
                courseEndCalendar.set(Calendar.MONTH, month);
                // day
                courseEndCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update ending label
                updateEndingCourseLabel();

            }


        };


        // new start date picker dialog
        beginCourseDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year from the begin calendar
                courseStartCalendar.set(Calendar.YEAR, year);
                // month
                courseStartCalendar.set(Calendar.MONTH, month);
                // day
                courseStartCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update start label method
                updateStartingCourseLabel();

            }
        };


//        // course start - leave space to change with date picker
//        changeCourseBeginDate = findViewById(R.id.changeCourseStartDayTvCourseDetails);
//        // get intent start date
//        // set courseStartDate to new on date set listener
//        courseStartDate = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                // adding the calender object for beginning and setting it to year month day
//                courseStartCalender.set(Calendar.YEAR, year);
//
//                courseStartCalender.set(Calendar.MONTH, month);
//
//                courseStartCalender.set(Calendar.DAY_OF_MONTH, day);
//
//                updateStartingCourseLabel();
//
//            }
//        };

        /*(((&*&*&*&*((((()((&*&     SPINNER FOR COURSE STATUS     &*&*&))))))))))))((&*&*&*&((&*&*&*&

         ))))))))))))((&*&*&*&(())))))))))))((&*&*&*&(())))))))))))((&*&*&*&(())))))))))))((&*&*&*&((*/

        /***
         ** 8.-making the spinner for the course status
         */
//
//        Spinner classStatusSpinner = (Spinner) findViewById(R.id.statusSpinner);
//        // need an array adapter
//        ArrayAdapter<CharSequence> statusArrayAdapter = ArrayAdapter.createFromResource(this,
//                R.array.status_list, android.R.layout.simple_spinner_item);
//        statusArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
//        classStatusSpinner.setAdapter(statusArrayAdapter);

//        // using an if statement with else if tos set the status
//        if(status == null){
//            classStatusSpinner.setSelection(1);
//        }


//        courseStartDate = getIntent().getStringExtra("beginDate");
//        // setText start date
//        changeCourseBeginDate.setText(courseStartDate);


        // course end - same as above
//        changeCourseEndDate = findViewById(R.id.changeCourseEndDayTvCourseDetails);
//        // getIntent end date
//        // set courseEndDate to new ondate lister
//        courseEndDate = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                //setting courseEndCalender to calendar in year, month, day
//                courseEndCalender.set(Calendar.YEAR, year);
//
//                courseEndCalender.set(Calendar.MONTH, month);
//
//                courseEndCalender.set(Calendar.DAY_OF_MONTH, day);
//
//                updateEndingCourseLabel();
//
//            }
//        };

        // changeCourseBeginDate set new Onclick listener to click on it
//        changeCourseBeginDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Date couresStartDateW;
//
//                String info = changeCourseBeginDate.getText().toString();
//
//                if (info.equals("")) info = "12/01/2023";
//
//                // try and catch statement
//                try {
//                    courseStartCalender.setTime(sdf.parse(info));
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//                new DatePickerDialog(CourseDetailPage.this, courseStartDate,
//
//                        // adding year
//                        courseStartCalender.get(Calendar.YEAR),
//                        // adding month
//                        courseStartCalender.get(Calendar.MONTH),
//                        // adding day
//                        courseStartCalender.get(Calendar.DAY_OF_MONTH)).show();
//
//            }
//        });
//        courseEndDate = getIntent().getStringExtra("endDate");
//        // setText end date
//        changeCourseEndDate.setText(courseEndDate);

        //changeCourseEndDate set to newOnclickListener
//        changeCourseEndDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Date couresEndDateW;
//
//                String info = changeCourseEndDate.getText().toString();
//
//                if (info.equals("")) info = "12/01/2023";
//
//                // try and catch statement
//                try {
//                    courseEndCalender.setTime(sdf.parse(info));
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//                new DatePickerDialog(CourseDetailPage.this, courseEndDate,
//
//                        // adding year
//                        courseEndCalender.get(Calendar.YEAR),
//                        // adding month
//                        courseEndCalender.get(Calendar.MONTH),
//                        // adding day
//                        courseEndCalender.get(Calendar.DAY_OF_MONTH)).show();
//
//            }
//        });


        //instructor info name
        changeTeacherName = findViewById(R.id.changeTeacherNameTvCourseDetails);
        // getIntent for teacherName
        teacherName = getIntent().getStringExtra("courseInstructorName");
        // setText for teacherName
        changeTeacherName.setText(teacherName);


        // instructor phone number
        changeTeachersPhone = findViewById(R.id.changeTeacherPhoneTvCourseDetails);
        // get intent for teacher phone
        teacherPhone = getIntent().getStringExtra("courseInstructorPhoneNumber");
        // settext for phone
        changeTeachersPhone.setText(teacherPhone);


        // instructors email
        changeTeachersEmail = findViewById(R.id.changeTeacherEmailTvCourseDetails);
        //getIntent for email
        teacherEmail = getIntent().getStringExtra("courseInstructorEmail");
        // setText for email
        changeTeachersEmail.setText(teacherEmail);


        // random info note
        changeCourseNote = findViewById(R.id.changeCourseNotesTvCourseDetails);
        //getItent for Note
        notes = getIntent().getStringExtra("courseNotes");
        // setText for note
        changeCourseNote.setText(notes);


        //course ID
        courseID = getIntent().getIntExtra("id", -1);
        // term id
        termID = getIntent().getIntExtra("termID", -1);


//
//        //spinner part for choosing term
//        Spinner spinnerForTerm = findViewById(R.id.spinner2);
//
//        // making the array adapter
//        ArrayAdapter<Term> termArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
//                repository.getmAllTerms());
//
//        spinnerForTerm.setAdapter(termArrayAdapter);
//
//        spinnerForTerm.setOnItemSelectedListener();


//////        // status - going to a drop down/spinner so change
////        changeStatus = findViewById(R.id.changeCourseStatusTvCourseDetails);
////        // getIntent for status
//       status = getIntent().getStringExtra("courseStatus");
////
//
//        //get the status of spinner
//
//
//
//        // status now with spinner
//         changeStatus = findViewById(R.id.statusSpinner);
//        // need an array adapter
//        ArrayAdapter<CharSequence> statusOfCoursesAdapter = ArrayAdapter.createFromResource(this,
//                R.array.courseStatus, android.R.layout.simple_spinner_item);
//        // setting the courseAdapter
//        statusOfCoursesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
//        changeStatus.setAdapter(statusOfCoursesAdapter);
//
//        // repository will get new part
//        repository = new Repository(getApplication());
//
//
//        // multiple if statement
//        if(status != null){
//
//            // plan to take status
//            if (status.equals("Plan To Take")){
//                changeStatus.setSelection(0);
//            }
//
//            // in progress status
//            if(status.equals("In Progress")){
//                changeStatus.setSelection(1);
//            }
//
//            if(status.equals("Completed")){
//                changeStatus.setSelection(2);
//            }
//
//            if(status.equals("Dropped")){
//                changeStatus.setSelection(3);
//            }
//
//            //
//        }


        /***
         ** - 1. adding the associated course recycle view
         ** -  copying the code from the terms page
         */
        RecyclerView testRecyclerViewForDetailPage = findViewById(R.id.testListRecyclerView);
// repository
        repository = new Repository(getApplication());
        // querying the database

        // need course Adapter
        final AssessmentsAdapter testsAdapter= new AssessmentsAdapter(this);
        testRecyclerViewForDetailPage.setAdapter(testsAdapter);
        testRecyclerViewForDetailPage.setLayoutManager(new LinearLayoutManager(this));
        // new list for the filteredCourses
        List<Assessment> filteredTests = new ArrayList<>();
        // for loop
        for(Assessment t: repository.getmAllTests()){
            if(t.getCourseID() == courseID) filteredTests.add(t);
        }
        testsAdapter.setTests(filteredTests);
/***
 ** going to get a filtered list instead of all the of the tests
 */
        //  need to get it from the repository and put it on the list
        //List<Assessment> allAvailableTestsForDetailPage = repository.getmAllTests();
       // List<Assessment> filteredTestsForCourseDetailPage = repository.get

//        // termAdapter
//        final AssessmentsAdapter assessmentsAdapter = new AssessmentsAdapter(this);
//
//        // setting on the recyclerView
//        testRecyclerViewForDetailPage.setAdapter(assessmentsAdapter);
//
//        // layout view to recycler view
//        testRecyclerViewForDetailPage.setLayoutManager(new LinearLayoutManager(this));

        // adding a list
//        List<Course> filteredCourse = new ArrayList<>();
//        for(Course c: repository.getmAllCourses()){
//            if(c.getTermID() == termID) filteredCourse.add(c);
//        }

        // adapter.set method to get the list to show all the courses
//        assessmentsAdapter.setTests(repository.getmAllTests());


    }


    /*(****)---(****)---     METHODS    (****)--- (****)--- (****)--- (****)---

            (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)---  */


    private void updateStartingCourseLabel() {
        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeBegDateForCourse.setText(sdf.format(courseStartCalendar.getTime()));
    }

    private void updateEndingCourseLabel() {
        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeEndDateForCourse.setText(sdf.format(courseEndCalendar.getTime()));
    }


    public void createSpinner() {
        // calling and updating the repository
        Repository repository = new Repository(getApplication());

        // getting terms
        terms = repository.getmAllTerms();

        // creating a list of all terms to hold it
        // I want the termNames to drop it down
        List<String> termNames = new ArrayList<>();

        // for loop to go through all of the terms to find the one that matches
        for (Term term : terms){
            termNames.add(term.getTermName());
        }

        // adding the new adapter
        ArrayAdapter<String> termSpinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, termNames);
        spinner2.setAdapter(termSpinnerAdapter);
    }


    public boolean onCreateOptionsMenu(Menu courseDetailMenu) {
        getMenuInflater().inflate(R.menu.menu_course_detail_page, courseDetailMenu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem courseMenuItemToPick) {
        if (courseMenuItemToPick.getItemId() == R.id.cancel) {
            Intent goBackToCourses = new Intent(CourseDetailPage.this, Courses.class);
            Toast.makeText(CourseDetailPage.this,
                    // test to make sure it go to the page
                    "Canceling Request",
                    Toast.LENGTH_SHORT).show();
            startActivity(goBackToCourses);

            return true;
        }
        /***
         ** 5. - save button that will save the list
         */
        if (courseMenuItemToPick.getItemId() == R.id.saveCourse) {
            if (courseID == -1) {
                // if status is found
//                courseStatus = courseStatusSpinner.getSelectedItem().toString();
                // if course isn't found create new course
                course = new Course(0, changeCourseName.getText().toString(),
                        changeBegDateForCourse.getText().toString(),
                        changeEndDateForCourse.getText().toString(),
                        changeTeacherName.getText().toString(),
                        changeTeachersPhone.getText().toString(),
                        changeTeachersEmail.getText().toString(),
                        changeCourseNote.getText().toString(),
                        courseStatusSpinner.getSelectedItem().toString(), termID);
                // need to insert the new course into the repository
                repository.insertCourse(course);

            } else {
                course = new Course(courseID, changeCourseName.getText().toString(),
                        changeBegDateForCourse.getText().toString(),
                        changeEndDateForCourse.getText().toString(),
                        changeTeacherName.getText().toString(),
                        changeTeachersPhone.getText().toString(),
                        changeTeachersEmail.getText().toString(),
                        changeCourseNote.getText().toString(),
                        courseStatusSpinner.getSelectedItem().toString(), termID);
                repository.updateCourse(course);
            }
            /***
             ** 8. going to go back to the course list screen
             */


            Intent goBackToCourseList = new Intent(CourseDetailPage.this, Courses.class);
            startActivity(goBackToCourseList);
        }
        /***
         ** 6. - share course note
         */
        if (courseMenuItemToPick.getItemId() == R.id.shareNoteItem) {

            // added note field
            Intent sentNoteIntent = new Intent();

            sentNoteIntent.setAction(Intent.ACTION_SEND);
            sentNoteIntent.putExtra(Intent.EXTRA_TEXT,
                    "I am sharing Course Notes from " + changeCourseName.getText().toString() + ": " +
                            changeCourseNote.getText().toString());
            sentNoteIntent.putExtra(Intent.EXTRA_TITLE,
                    "Sharing Course Notes");

            sentNoteIntent.setType("text/plain");

            Intent shareIntent = Intent.createChooser(sentNoteIntent, null);

            startActivity(shareIntent);

            return true;
        }

        /***
         ** 8. - need to add the alert me menu start date
         */
        if (courseMenuItemToPick.getItemId() == R.id.notifyCourseDetails) {

            // begin date for course
            String startCourseDateFromBefore = changeBegDateForCourse.getText().toString();

            String myCourseBeginFormat = "MM/dd/yy";

            SimpleDateFormat sdf = new SimpleDateFormat(myCourseBeginFormat, Locale.US);

            Date courseBeginDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                courseBeginDateForHere = sdf.parse(startCourseDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long trigger = courseBeginDateForHere.getTime();
            // need to build the receiver
            Intent receiveMessageFromReceiverBeg = new Intent(CourseDetailPage.this, MyReceiver.class);
            // message to add on what I want them to see
            receiveMessageFromReceiverBeg.putExtra("key", courseBeginDateForHere + "should trigger");

            // sender
            PendingIntent senderBeginCourse = PendingIntent.getBroadcast(CourseDetailPage.this, ++MainActivity.numStartAlertCourse,
                    receiveMessageFromReceiverBeg, PendingIntent.FLAG_IMMUTABLE);

            // getting the alarm clock to wake it up
            AlarmManager courseStartAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            // set the alarm
            courseStartAlarmManager.set(AlarmManager.RTC_WAKEUP, trigger, senderBeginCourse);


            return true;


        }

        /***
         ** 8. - need to add the alert me menu end date
         */
        if (courseMenuItemToPick.getItemId() == R.id.notifyCourseEndDetails) {

            // end date for course notification
            String endCourseDateFromBefore = changeEndDateForCourse.getText().toString();

            String myCourseEndFormat = "MM/dd/yy";

            SimpleDateFormat sidf = new SimpleDateFormat(myCourseEndFormat, Locale.US);

            Date courseEndDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                courseEndDateForHere = sidf.parse(endCourseDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long triggerEnd = courseEndDateForHere.getTime();
            // making a new intent
            Intent receiveMessageFromReceiverEnd = new Intent(CourseDetailPage.this, MyReceiver.class);
            receiveMessageFromReceiverEnd.putExtra("key", courseEndDateForHere + "should trigger!");

            // sender
            PendingIntent senderEndCourse = PendingIntent.getBroadcast(CourseDetailPage.this, ++MainActivity.numEndAlertCourse,
                    receiveMessageFromReceiverEnd, PendingIntent.FLAG_IMMUTABLE);

            // alarm clock to wake it up
            AlarmManager courseEndAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            // setting the alarm with the wakeupcall
            courseEndAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerEnd, senderEndCourse);

        }

        // delete button
        if (courseMenuItemToPick.getItemId() == R.id.deleteCourse) {
            // deleting a course

            // using a for each loop
            for (Course crs : repository.getmAllCourses()) {
                if (crs.getCourseID() == courseID) crntCrs = crs;
            }

            // need to check on if there are a number of tests attached
            numberOfTestsAttached = 0;

            // need to do another for loop need to know which courses are with each tests
            for (Assessment assessment : repository.getmAllTests()) {
                // if courses attached = to termId then increment
                if (assessment.getCourseID() == courseID) ++numberOfTestsAttached;
            }
            if (numberOfTestsAttached == 0) {
                // if there aren't any tests attached then you can delete
                repository.deleteCourse(crntCrs);

                // adding toast message to show which course got deleted
                Toast.makeText(CourseDetailPage.this, crntCrs.getCourseName() +
                        " was deleted from the list.", Toast.LENGTH_LONG).show();
                // going back to courses list
                Intent goBackToCourseScreen = new Intent(CourseDetailPage.this, Courses.class);
                startActivity(goBackToCourseScreen);

            }

            // creating another toast message to say  that you can't delete a term with a course
            // attached to the term, delete the course first
            else {
                Toast.makeText(CourseDetailPage.this,
                        "You can't delete the course. Please delete the associated assessment",
                        Toast.LENGTH_LONG).show();

            }

        }


        // issues with else trying again after video
        // else if it is found then we will update the course
//            else {
//                courseID, changeCourseName.getText().toString(),
//                        changeCourseBeginDate.getText().toString(),
//                        changeCourseEndDate.getText().toString(),
//                        changeTeacherName.getText().toString(),
//                        changeTeachersPhone.getText().toString(),
//                        changeTeachersEmail.getText().toString(),
//                        changeCourseNote.getText().toString(),
//                        changeStatus.getText().toString());
//
//
//                        // update course in repository
//                        repository.updateCourse(course);
//            }

//
//        }


        return true;
    }


/****
 *** end of the line
 *** don't continue
 **/
/*(****)---(****)---     REQUIREMENTS    (****)--- (****)--- (****)--- (****)---
    - can't deleted associated tests with it
    - need to be delete, add, and update

    (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)--- (****)---  */
}