package com.example.myschoolapp.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.myschoolapp.entities.Term;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/

@Dao
public interface TermDAO {

    /***
     ** 1. - update, insert, delete, get all Terms
     */

    // update
    @Update
    void updateTerm(Term term);

    //delete
    @Delete
    void deleteTerm(Term term);

    // insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertTerm(Term term);

    //get all terms
@Query("SELECT * FROM terms ORDER BY termID ASC")
    List<Term> getAllTerms();



}
