package com.example.myschoolapp.Activity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Course;

import java.util.List;

public class AssessmentsAdapter extends RecyclerView.Adapter<AssessmentsAdapter.AssessmentsViewholder> {
    /***
     ** - 3. create the list of terms up top
     */
    private List<Assessment> mTests;


    /***
     ** - declaring the context
     */
    private final Context context;

    /***
     ** - declaring the inflater
     */
    private final LayoutInflater mInflater;

    public class AssessmentsViewholder extends RecyclerView.ViewHolder {
        /***
         ** - tests_item layout only has 1 text view
         */
        private final TextView testItemListView;
       private final TextView assTestsItemView;


        public AssessmentsViewholder(@NonNull View itemView) {
            super(itemView);
            testItemListView = itemView.findViewById(R.id.testsItemView);
         assTestsItemView = itemView.findViewById(R.id.assTestsItemView);


            testItemListView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int testPosition = getAdapterPosition();
                    final Assessment currentTest = mTests.get(testPosition);// creating a method to get it

                    // need to go to the assessment detail page
                    Intent goToTestDetailPageBridge = new Intent(context, AssessmentDetailPage.class);

                    /***
                     ** - 7. need to use the putExtra method
                     ** - we need test id, tes name, term start and end dates
                     ** - need type of test whether its performance or objective
                     ** - course id
                     ** - need to go to the next screen or start the activity after
                     */
                    // test id
                    goToTestDetailPageBridge.putExtra("assessmentID", currentTest.getTestID());
                    // test name
                    goToTestDetailPageBridge.putExtra("assessmentName", currentTest.getTestName());


                    // begin date - changing due to date picker
                    goToTestDetailPageBridge.putExtra("beginDate", currentTest.getBeginTestDay());
                    // end date - changing due to dae picker
                    goToTestDetailPageBridge.putExtra("endDate", currentTest.getEndTestDay());


                    // type of test - changing because plan on using radio button
                    goToTestDetailPageBridge.putExtra("testType", currentTest.getTypeOfTest());


                    // need course id
                    goToTestDetailPageBridge.putExtra("courseID", currentTest.getCourseID());
                    // going to the next activity
                    context.startActivity(goToTestDetailPageBridge);


                }
            });


        }
    }


    /***
     ** - 6. onCreateViewHolder
     ** - need to inflate
     */
    @NonNull
    @Override
    public AssessmentsAdapter.AssessmentsViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = mInflater.inflate(R.layout.tests_item_layout,
                parent, false);


        // need to return the viewHolder
        return new AssessmentsViewholder(itemView);

    }




    /***
     ** 8. - this is where we will display where we want to put it on the recylcer view
     ** - can't be null, using if
     */
    @Override
    public void onBindViewHolder(@NonNull AssessmentsAdapter.AssessmentsViewholder holder, int position) {




        if(mTests != null){
            Assessment currentTestForBindView = mTests.get(position);
            String nameToFind = currentTestForBindView.getTestName();
            holder.testItemListView.setText(nameToFind);
        }
        else{
            holder.testItemListView.setText("No Test Found");
        }

    }


    /***
     ** 4. - getItem method
     **  - need to change return from 0 to mTests
     */
    @Override
    public int getItemCount() {
        if (mTests != null) {
            return mTests.size();
        } else
            return 0;
    }


    /***
     ** 2. - method for setting the list
     */

    public void setTests(List<Assessment> tests) {
        mTests = tests;
        notifyDataSetChanged();
    }

    /***
     ** 5. - method for the inflator
     */
    public AssessmentsAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context = context;


    }

}
