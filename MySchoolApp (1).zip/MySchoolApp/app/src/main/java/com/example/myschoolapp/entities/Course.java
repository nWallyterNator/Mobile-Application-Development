package com.example.myschoolapp.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/****
 *** @author Nicholas Walters
 **/


@Entity(tableName = "courses")
public class Course {
    /***
     ** 1. - need course name
     **    - course id pk
     **    - start and end days
     **    - Instructors name, phone, email
     **    - Course Notes
     **    - Course Status
     **    - Term id( foreign key ish)
      */


    @PrimaryKey(autoGenerate = true)
    private int courseID;

    private String courseName;

    private String courseStartDay, courseEndDay;

    private String instructorsName,instructorsPhoneNumber,instructorsEmailAddress;

    private String courseNotes;

    private String courseStatus;

    private int termID;


/***
 ** 2. - need to generate constructor
 */
    public Course(int courseID, String courseName, String courseStartDay, String courseEndDay, String instructorsName, String instructorsPhoneNumber, String instructorsEmailAddress, String courseNotes, String courseStatus, int termID) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.courseStartDay = courseStartDay;
        this.courseEndDay = courseEndDay;
        this.instructorsName = instructorsName;
        this.instructorsPhoneNumber = instructorsPhoneNumber;
        this.instructorsEmailAddress = instructorsEmailAddress;
        this.courseNotes = courseNotes;
        this.courseStatus = courseStatus;
        this.termID = termID;
    }
    /***
     ** 3. - generate the getters and setters
     */
    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseStartDay() {
        return courseStartDay;
    }

    public void setCourseStartDay(String courseStartDay) {
        this.courseStartDay = courseStartDay;
    }

    public String getCourseEndDay() {
        return courseEndDay;
    }

    public void setCourseEndDay(String courseEndDay) {
        this.courseEndDay = courseEndDay;
    }

    public String getInstructorsName() {
        return instructorsName;
    }

    public void setInstructorsName(String instructorsName) {
        this.instructorsName = instructorsName;
    }

    public String getInstructorsPhoneNumber() {
        return instructorsPhoneNumber;
    }

    public void setInstructorsPhoneNumber(String instructorsPhoneNumber) {
        this.instructorsPhoneNumber = instructorsPhoneNumber;
    }

    public String getInstructorsEmailAddress() {
        return instructorsEmailAddress;
    }

    public void setInstructorsEmailAddress(String instructorsEmailAddress) {
        this.instructorsEmailAddress = instructorsEmailAddress;
    }

    public String getCourseNotes() {
        return courseNotes;
    }

    public void setCourseNotes(String courseNotes) {
        this.courseNotes = courseNotes;
    }

    public String getCourseStatus() {
        return courseStatus;
    }

    public void setCourseStatus(String courseStatus) {
        this.courseStatus = courseStatus;
    }

    public int getTermID() {
        return termID;
    }

    public void setTermID(int termID) {
        this.termID = termID;
    }


    /****
     *** end of the line
     *** don't continue
     **/
}
