package com.example.myschoolapp.Activity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Course;
import com.example.myschoolapp.entities.Term;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;


/****
 *** @author Nicholas Walters
 **/
public class AssessmentDetailPage extends AppCompatActivity {
    /***
     ** 9. - spinner for the courses
     ** - list of courses
     */
    // spinner
    Spinner courseAndTestSpinner;

    // list of Courses
    List<Course> courses;


    /*** 4. - buttons, save and cancel
     **
     */
    // 2 visible buttons, save test and cancel button
    Button saveTestBtn, cancelBtn;

    /*** 1. - need test name
     **  -  need to set the test name
     */
    // Edit name
    EditText changeTestName;
    // set test name string
    String testName;

    /***
     **  2. - need start and end dates
     **  -  dialog date pickers for begin and end dates
     **  -  strings needed for dates
     */
    //text view needed for begining date and ending date
    TextView changeBegDateForTest, changeEndDateForTest;

    // dialog begin and end dates
    DatePickerDialog.OnDateSetListener beginTestDate, endTestDate;

    //Calenders start and end for test
    final Calendar testStartCalendar = Calendar.getInstance();
    final Calendar testEndCalendar = Calendar.getInstance();

    // strings for start and begin date
    String startingTestDate, endingTestDate;


    /***
     **  3. - need test type
     **  - using a type spinner
     **  - the setter will be a string
     **  - need to make a position
     */

    // string to get
    String typeOfTest;
    Spinner testSpinnerType;


    /***
     ** 5. - test id, course id
     */
    // need a termId
    int testID;
    int courseID;

    /***
     ** 6. - need a Assessment to name as test for the save button
     */
    Assessment test;

    /***
     ** 7. - repository needed
     */
    Repository repository;

    /**
     * * 8. - need a current test to delete
     */
    Assessment crntTest;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_detail_page);

        repository = new Repository(getApplication());

        /***
         ** 9 . calling the spinner by the id
         ** - calling a method to get the spinner for the courses that go with
         ** - need to make it clickable
         */
        courseAndTestSpinner = findViewById(R.id.courseAndTestSpinner);
        // calling spinner
        createAssCoursesSpinner();
        // making it clickable
        courseAndTestSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // getting a new course
                // getting i which is the position
                Course chosenCourse = courses.get(i);
                courseID = chosenCourse.getCourseID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        /***
         ** 1. - need ids and to get the test name, setting
         */
        // id for changeTestName
        changeTestName = findViewById(R.id.changeTestNameEv);
        // getting test name from adapter
        testName = getIntent().getStringExtra("assessmentName");

        // setting name
        changeTestName.setText(testName);


        /***
         ** 2. - date need to set a simple string
         */
        // adding format for date and adding a string
        String myFormatForCalendar = "MM/dd/yy";
        // adding SimpleDateFormat
        SimpleDateFormat sdf = new SimpleDateFormat(myFormatForCalendar, Locale.US);

        /***
         ** 3. - need ids for spinner
         ** - getter for spinner
         ** - getting the data for the spinner
         */
        testSpinnerType = findViewById(R.id.testSpinnerType);

        //getter for spinnner
        typeOfTest = getIntent().getStringExtra("testType");

        // info for spinner
        ArrayAdapter<CharSequence> testAdapter = ArrayAdapter.createFromResource(this,
                R.array.test_type, android.R.layout.simple_spinner_dropdown_item);
        testAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        testSpinnerType.setAdapter(testAdapter);

        // to make sure it will add it
        if (testID != -1) {
            int testStatusPosition = testAdapter.getPosition(typeOfTest);
            testSpinnerType.setSelection(testStatusPosition);

        }


        /***
         ** 5. - getting test id from adapter and course id
         */
        testID = getIntent().getIntExtra("assessmentID", -1);
        // course id
        courseID = getIntent().getIntExtra("courseID", -1);


        /***
         ** 2. - getting a new calendar and set method
         ** - need ids
         ** - get the starting and end date info from adapters
         ** - setting the date
         ** - need to make it a button to make it clickable
         ** - new dialogs needed
         */
        // ids
        //ids
        changeBegDateForTest = findViewById(R.id.changTestStartDateEv);
        changeEndDateForTest = findViewById(R.id.changeTestEndDate);

        //getting the info from the strings from the adapter
        startingTestDate = getIntent().getStringExtra("beginDate");
        endingTestDate = getIntent().getStringExtra("endDate");

        //setting
        // setting info using an if statement if its at -1
        if (testID == -1) {
            changeBegDateForTest.setText(sdf.format(new Date()));
            changeEndDateForTest.setText(sdf.format(new Date()));
            // if it is found
            // else statement
        } else {
            changeEndDateForTest.setText(endingTestDate);
            changeBegDateForTest.setText(startingTestDate);
        }

        // making it a button to be clickable
        //start date
        changeBegDateForTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeBegDateForTest.getText().toString();

                if (info.equals("")) info = "12/01/23";
                // try and catch statement
                try {
                    // calling the begin calendar
                    testStartCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog date picker
                new DatePickerDialog(AssessmentDetailPage.this, beginTestDate,
                        testStartCalendar.get(Calendar.YEAR),
                        //month for calender
                        testStartCalendar.get(Calendar.MONTH),
                        // day of the month
                        testStartCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // end date button
        changeEndDateForTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // need to get the info from the user
                String info = changeEndDateForTest.getText().toString();

                if (info.equals("")) info = "12/01/23";
                //try and catch statement
                try {
                    //calling the end calender
                    testEndCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                // need a new dialog datepicker
                new DatePickerDialog(AssessmentDetailPage.this, endTestDate, testEndCalendar
                        .get(Calendar.YEAR),
                        //month
                        testEndCalendar.get(Calendar.MONTH),
                        // day
                        testEndCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        // new end date new date picker dialog
        endTestDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year
                testEndCalendar.set(Calendar.YEAR, year);
                // month
                testEndCalendar.set(Calendar.MONTH, month);
                // day
                testEndCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update ending label
                updateEndingTestLabel();

            }


        };
        // new start date picker dialog
        beginTestDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // year from the begin calendar
                testStartCalendar.set(Calendar.YEAR, year);
                // month
                testStartCalendar.set(Calendar.MONTH, month);
                // day
                testStartCalendar.set(Calendar.DAY_OF_MONTH, day);

                // calling update start label method
                updateStartingTestLabel();

            }
        };

        /***
         ** 4. - buttons = save and cancel button
         */
        saveTestBtn = findViewById(R.id.saveTestDetailBTT);
        //  the save button should save info and go back to the previous page
        saveTestBtn.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {


                // need to make sure that test id is found
                if (testID == -1) {
                    // if term isn't found create new term
                    test = new Assessment(0, changeTestName.getText().toString(),
                            changeBegDateForTest.getText().toString(),
                            changeEndDateForTest.getText().toString(), testSpinnerType.getSelectedItem().toString(),
                            courseID);
                    // need to insert the new term into the repository
                    repository.insertTest(test);

                    // going back to the screen to refresh so we can see if it worked vs going back and forth
                    Intent goBackWithSavedTest = new Intent(AssessmentDetailPage.this,
                            Assessments.class);
                    startActivity(goBackWithSavedTest);
                }
                // else if it is found then we will update the term
                else {
                    test = new Assessment(testID, changeTestName.getText().toString(),
                            changeBegDateForTest.getText().toString(),
                            changeEndDateForTest.getText().toString(), testSpinnerType.getSelectedItem().toString(), courseID);
                    // update term in repository
                    repository.updateTest(test);

                    // going back to the screen to refresh so we can see if it worked vs going back and forth
                    Intent goBackWithSavedTest = new Intent(AssessmentDetailPage.this,
                            Assessments.class);
                    startActivity(goBackWithSavedTest);
                }


                //

            }
        });


        //Cancel Btn
        cancelBtn = findViewById(R.id.cancelTestDetailBTT);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackToTests = new Intent(AssessmentDetailPage.this, Assessments.class);

                Toast.makeText(AssessmentDetailPage.this,
                        // test to make sure it go to the page
                        "Canceling Request",
                        Toast.LENGTH_SHORT).show();
                startActivity(goBackToTests);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_assessment_detail_page, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {


        if (menuItem.getItemId() == R.id.deleteTestAssessmentDetailsPageMenuItem) {
            // deleting a test

            // using a for each loop
            for (Assessment tst : repository.getmAllTests()) {
                if (tst.getTestID() == testID) {
                    Assessment crntTest = tst;
                    repository.deleteTest(crntTest);
                }

            }
            // adding toast message to show which test got deleted
            Toast.makeText(AssessmentDetailPage.this, crntTest.getTestName() +
                    " was deleted from the list.", Toast.LENGTH_LONG).show();
            // going back to tests list
            Intent goBackToTestsScreen = new Intent(AssessmentDetailPage.this, Terms.class);
            startActivity(goBackToTestsScreen);

            return true;
        }

        /***
         ** 4. - need to add the alert me menu start date
         */
        if (menuItem.getItemId() == R.id.testStartDate) {

            // begin date for test
            String startTestDateFromBefore = changeBegDateForTest.getText().toString();

            String myTestBeginFormat = "MM/dd/yy";

            SimpleDateFormat sdf = new SimpleDateFormat(myTestBeginFormat, Locale.US);

            Date testBeginDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                testBeginDateForHere = sdf.parse(startTestDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long trigger = testBeginDateForHere.getTime();
            // need to build the receiver
            Intent receiveMessageFromReceiverBeg = new Intent(AssessmentDetailPage.this, MyReceiver.class);
            // message to add on what I want them to see
            receiveMessageFromReceiverBeg.putExtra("key", testBeginDateForHere + "should trigger");

            // sender
            PendingIntent senderBeginTest = PendingIntent.getBroadcast(AssessmentDetailPage.this, ++MainActivity.numStartAlertTest,
                    receiveMessageFromReceiverBeg, PendingIntent.FLAG_IMMUTABLE);

            // getting the alarm clock to wake it up
            AlarmManager testStartAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            // set the alarm
            testStartAlarmManager.set(AlarmManager.RTC_WAKEUP, trigger, senderBeginTest);


            return true;


        }

        /***
         ** 8. - need to add the alert me menu end date
         */
        if (menuItem.getItemId() == R.id.testEndDate) {

            // end date for course notification
            String endTestDateFromBefore = changeEndDateForTest.getText().toString();

            String myTestEndFormat = "MM/dd/yy";

            SimpleDateFormat sidf = new SimpleDateFormat(myTestEndFormat, Locale.US);

            Date testEndDateForHere = null;

            //parse the data from the screen to pull the date from the screen
            // try catch
            try {
                testEndDateForHere = sidf.parse(endTestDateFromBefore);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // trigger
            Long triggerEnd = testEndDateForHere.getTime();
            // making a new intent
            Intent receiveMessageFromReceiverEnd = new Intent(AssessmentDetailPage.this, MyReceiver.class);
            receiveMessageFromReceiverEnd.putExtra("key", testEndDateForHere + "should trigger!");

            // sender
            PendingIntent senderEndTest = PendingIntent.getBroadcast(AssessmentDetailPage.this, ++MainActivity.numEndAlertTest,
                    receiveMessageFromReceiverEnd, PendingIntent.FLAG_IMMUTABLE);

            // alarm clock to wake it up
            AlarmManager testEndAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            // setting the alarm with the wakeupcall
            testEndAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerEnd, senderEndTest);

        }

        return super.onOptionsItemSelected(menuItem);
    }








 /*@@$@$$$$@@@@$@$$$$@@ @@$@$$$$@@      METHODS    @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@

   @@$@$$$$@@@@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@ @@$@$$$$@@   */
public  void createAssCoursesSpinner(){
    // calling and updating the repository
    Repository repository = new Repository(getApplication());

    // getting courses
    courses = repository.getmAllCourses();

    // creating a list of all courses to hold it
    // I want the course names to drop it down
    List<String> courseNames = new ArrayList<>();

    // for loop to go through all of the courses to find the one that matches
    for (Course course : courses){
        courseNames.add(course.getCourseName());
    }

    // adding the new adapter
    ArrayAdapter<String> courseSpinnerAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, courseNames);
    courseAndTestSpinner.setAdapter(courseSpinnerAdapter);
}


    private void updateEndingTestLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeEndDateForTest.setText(sdf.format(testEndCalendar.getTime()));


    }

    private void updateStartingTestLabel() {

        String myFormat = "MM/dd/yy";

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        changeBegDateForTest.setText(sdf.format(testStartCalendar.getTime()));
    }


    /****
     *** end of the line
     *** don't continue
     **/
    /*%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%    REQUIREMENTS     %%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%
    - need to add as many tests as I want
    - need a performance and objective option for each course
    - add the titles for each test
    - add, update delete
    - beginning and end dates


    %%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%%%%$$^^&&%%%
  */
}