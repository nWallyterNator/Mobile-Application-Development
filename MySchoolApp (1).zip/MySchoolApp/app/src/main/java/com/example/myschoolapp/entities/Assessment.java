package com.example.myschoolapp.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/****
 *** @author Nicholas Walters
 **/

@Entity(tableName = "assessments")
public class Assessment {
    /***
     ** 1. - need to get testname
     **    - begin and end days
     **    - type of test
     **    -  id(pk) for test
     **    -  id(fk) for test
     */
@PrimaryKey(autoGenerate = true)
    private int testID;

    private String testName;

    private String beginTestDay, endTestDay;

    private String typeOfTest;

    private int courseID;

    /***
     ** 1. - need to get constructor
     */
    public Assessment(int testID, String testName, String beginTestDay, String endTestDay, String typeOfTest, int courseID) {
        this.testID = testID;
        this.testName = testName;
        this.beginTestDay = beginTestDay;
        this.endTestDay = endTestDay;
        this.typeOfTest = typeOfTest;
        this.courseID = courseID;
    }

    /***
     ** 2. - getters and setters
     */
    public int getTestID() {
        return testID;
    }

    public void setTestID(int testID) {
        this.testID = testID;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public String getBeginTestDay() {
        return beginTestDay;
    }

    public void setBeginTestDay(String beginTestDay) {
        this.beginTestDay = beginTestDay;
    }

    public String getEndTestDay() {
        return endTestDay;
    }

    public void setEndTestDay(String endTestDay) {
        this.endTestDay = endTestDay;
    }

    public String getTypeOfTest() {
        return typeOfTest;
    }

    public void setTypeOfTest(String typeOfTest) {
        this.typeOfTest = typeOfTest;
    }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    /****
     *** end of the line
     *** don't continue
     **/
}
