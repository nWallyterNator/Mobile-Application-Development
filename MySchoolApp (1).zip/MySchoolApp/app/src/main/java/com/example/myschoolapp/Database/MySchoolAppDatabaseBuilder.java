package com.example.myschoolapp.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.myschoolapp.DAO.AssessmentDAO;
import com.example.myschoolapp.DAO.CourseDAO;
import com.example.myschoolapp.DAO.TermDAO;
import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Course;
import com.example.myschoolapp.entities.Term;

/****
 *** @author Nicholas Walters
 **/
@Database(entities = {Term.class, Course.class, Assessment.class}, version = 28, exportSchema = false)
public abstract class MySchoolAppDatabaseBuilder extends RoomDatabase {

    public abstract CourseDAO courseDAO();

    public abstract TermDAO termDAO();

    public abstract AssessmentDAO assessmentDAO();

    private static volatile MySchoolAppDatabaseBuilder INSTANCE;

    static MySchoolAppDatabaseBuilder getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (MySchoolAppDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), MySchoolAppDatabaseBuilder.
                    class,"MyDatabase.db")
                        .fallbackToDestructiveMigration()
                            .build();


                }
            }
        }
        return INSTANCE;

}


/****
 *** end of the line
 *** don't continue
 **/
}
