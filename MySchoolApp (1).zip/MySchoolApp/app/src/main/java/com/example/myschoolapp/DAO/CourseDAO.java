package com.example.myschoolapp.DAO;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.myschoolapp.entities.Course;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/



@Dao
public interface CourseDAO {

    /***
     ** 1. - update, insert, delete, get all courses
     */


    // based on the video adding the @Insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertCourse(Course course);

    // adding the update
    @Update
    void updateCourse(Course course);

    // deleting the course
    @Delete void deleteCourse(Course course);

    // get all courses
    @Query("Select * FROM courses ORDER BY courseID ASC")
    List<Course> getAllCourses();
    @Query ("SELECT * FROM courses WHERE termID= :termID ORDER BY courseID ASC")
    List<Course> getAllFilteredCourses(int termID);



    /****
     *** end of the line
     *** don't continue
     **/
}
