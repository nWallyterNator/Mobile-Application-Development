package com.example.myschoolapp.entities;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

/****
 *** @author Nicholas Walters
 **/

@Entity(tableName = "terms")
public class Term {
    /***
     ** 1. - need term name, beginning date, end date
     */
    // per the video used an id, my table doesn't have one but maybe I still need it
    @PrimaryKey(autoGenerate = true)
    private int termID;

    private String termName;

    private String startTermDay, endTermDay;


    /**
     * * 2. - generating the getters and setters
     */

    public int getTermID() {
        return termID;
    }

    public void setTermID(int termID) {
        this.termID = termID;
    }

    public String getTermName() {
        return termName;
    }

    public void setTermName(String termName) {
        this.termName = termName;
    }

    public String getStartTermDay() {
        return startTermDay;
    }

    public void setStartTermDay(String startTermDay) {
        this.startTermDay = startTermDay;
    }

    public String getEndTermDay() {
        return endTermDay;
    }

    public void setEndTermDay(String endTermDay) {
        this.endTermDay = endTermDay;
    }


    /***
     ** 3. - generating the constructor
     */
    public Term(int termID, String termName, String startTermDay, String endTermDay ) {
        this.termID = termID;
        this.termName = termName;
        this.startTermDay = startTermDay;
        this.endTermDay = endTermDay;


/****
 *** end of the line
 *** don't continue
 **/
    }
}

