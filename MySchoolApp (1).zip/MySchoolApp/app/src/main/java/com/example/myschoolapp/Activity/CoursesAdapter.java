package com.example.myschoolapp.Activity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Course;


import java.util.List;

public class CoursesAdapter extends RecyclerView.Adapter<CoursesAdapter.CoursesViewHolder> {
    /***
     ** - 3. create the list of courses up top
     */
    private List<Course> mCourses;

    /***
     ** - declaring the context
     */
    private final Context context;

    /***
     ** - declaring the inflater
     */
    private final LayoutInflater mInflater;

    public CoursesAdapter(Context context) {
       mInflater = LayoutInflater.from(context);
       this.context= context;
    }


    public class CoursesViewHolder extends RecyclerView.ViewHolder {
        /***
         ** - course_item layout only has 1 text view
         */
        private final TextView courseItemListView;
        private final TextView associatedCoursesItemView;




        public CoursesViewHolder(@NonNull View itemView) {
            super(itemView);
            courseItemListView = itemView.findViewById(R.id.textViewCourseItemList);
            associatedCoursesItemView = itemView.findViewById(R.id.associatedCoursesItemView);



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int coursePosition = getAdapterPosition();
                    final Course currentCourse = mCourses.get(coursePosition); // need a method to get the current course on the list

                    // need to go to the course detail page
                    Intent goToCourseDetailPageBridge = new Intent(context, CourseDetailPage.class);

                    /***
                     ** - 7. need to use the putExtra method
                     ** - we need course id, course name, course start and end dates
                     ** - course instructors name, email, phone number
                     ** - course notes and course status
                     ** - term id
                     ** - need to go to the next screen or start the activity after
                     */
                    //id - this won't populate on the screen
                    goToCourseDetailPageBridge.putExtra("id", currentCourse.getCourseID());

                    // name
                    goToCourseDetailPageBridge.putExtra("name", currentCourse.getCourseName());


                    // begin date -  this will change because of the date picker
                    goToCourseDetailPageBridge.putExtra("beginDate", currentCourse.getCourseStartDay());


                    // end date - changing due to date picker
                    goToCourseDetailPageBridge.putExtra("endDate", currentCourse.getCourseEndDay());


                    // course instructor name
                    goToCourseDetailPageBridge.putExtra("courseInstructorName", currentCourse.getInstructorsName());
                    // course instructors email
                    goToCourseDetailPageBridge.putExtra("courseInstructorEmail", currentCourse.getInstructorsEmailAddress());
                    // course instructors phone
                    goToCourseDetailPageBridge.putExtra("courseInstructorPhoneNumber", currentCourse.getInstructorsPhoneNumber());


                    // course notes -  changing to share
                    goToCourseDetailPageBridge.putExtra("courseNotes", currentCourse.getCourseNotes());
                    // course status - changing with a dropdown/spinner
                    goToCourseDetailPageBridge.putExtra("courseStatus", currentCourse.getCourseStatus());


                    // term id
                    goToCourseDetailPageBridge.putExtra("termID", currentCourse.getTermID());
                    // going to other screen activity
                    context.startActivity(goToCourseDetailPageBridge);


                }
            });

        }
    }




    /***
     ** - 6. onCreateViewHolder
     ** - need to inflate
     */
    @NonNull
    @Override
    public CoursesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.course_item_layout,
                parent, false);



        // need to return the viewHolder
        return new CoursesViewHolder(itemView);

    }




    /***
     ** 8. - this is where we will display where we want to put it on the recylcer view
     ** - can't be null, using if
     */

    @Override
    public void onBindViewHolder(@NonNull CoursesViewHolder holder, int position) {


        if(mCourses != null){
            Course currentCourseForBindView = mCourses.get(position);
            String nameToFind = currentCourseForBindView.getCourseName();
            holder.courseItemListView.setText(nameToFind);
        }
        else{
            holder.courseItemListView.setText("No Course Found");


        }

    }






    /***
     ** 4. - getItem method
     **  - need to change return from 0 to mCourses
     */
    @Override
    public int getItemCount() {
        if (mCourses != null) {
            return mCourses.size();
        } else
            return 0;
    }


    /***
     ** 2. - method for setting the list
     */

    public void setCourses(List<Course> courses) {
        mCourses = courses;
        notifyDataSetChanged();
    }

    /***
     ** 5. - method for the inflator
     */



}
