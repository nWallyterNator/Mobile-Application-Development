package com.example.myschoolapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Course;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/
public class Courses extends AppCompatActivity {

    // I have 2 buttons
    Button homeCourseBtn, addACourseDetailBtn;

    // need to declare a repository for the repository on this page
    Repository courseRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        /***
         ** 2.this will go to the course detail page
         */
        addACourseDetailBtn = findViewById(R.id.goCourseDetail);
        addACourseDetailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent goToCourseDetailPage = new Intent(Courses.this, CourseDetailPage.class);

               Toast.makeText(Courses.this,
                        // test to make sure it go to the page
                       "Going to Course Detail Page",
                       Toast.LENGTH_SHORT).show();
               startActivity(goToCourseDetailPage);

            }

        });

        // need to go back to the main page after Canceling
        homeCourseBtn = findViewById(R.id.courseBtn);
        homeCourseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goBackFromCourses = new Intent(Courses.this, MainActivity.class);
                {
                    Toast.makeText(Courses.this,
                            // test to make sure it go to the page
                            "Canceling Request",
                            Toast.LENGTH_SHORT).show();
                    startActivity(goBackFromCourses);
                }
            }
        });


        /***
         ** 3. need to create the recycler view and populate it
         ** - will query the database or put something on it
         ** - adding with the getAll
         ** - need to call the course adapter
         ** - need to set the recycler view on the adapter
         ** - layout manager needs to be set to recyclerView
         ** - will use the adapter.set method to put the actual list on
         */
        RecyclerView courseRecyclerView = findViewById(R.id.courserecylerview);

        // querying the database
        courseRepository = new Repository(getApplication());

        //  need to get it from the repository and put it on the list
        List<Course> allAvailableCourses = courseRepository.getmAllCourses();


        // CourseAdapter
       final CoursesAdapter coursesAdapter = new CoursesAdapter(this);

        // set recyclerview to adapter
        courseRecyclerView.setAdapter(coursesAdapter);

        // layout view to recycler view
        courseRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // adapter set method to populate list
        coursesAdapter.setCourses(allAvailableCourses);


    }


    /***
     ** 3. - functionality with the menu button
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_courses, menu);
        return true;
    }

    /***
     ** 4. - this will take it to the courses list page
     */
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        // going to test details screen to add a test
        if (menuItem.getItemId() == R.id.testMenuPage) {
            Intent goToTestDetailScreen = new Intent(Courses.this, Assessments.class);

            Toast.makeText(Courses.this,
                    // test to make sure it go to the page
                    "Adding Test",
                    Toast.LENGTH_SHORT).show();
            startActivity(goToTestDetailScreen);
        }

        return true;
    }


        /****
         *** end of the line
         *** don't continue
         **/

      /*%$%^$$$%%$%^$$$%^^^$$#^ REQUIREMENTS  %$%^$$$%^^^$$#%$%^$$$%^^^$$#
    - need to be able to add as many courses as needed
    - list of courses with the term
    - need course title
    - need course start date, end date,
    - need course status which will either be
        --in progress, completed, dropped, planned to take
    - course instructor w/
        - name
        - phone number
        - email address
    - Requirement B needs list of courses


    ^#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#%$%^$$$%^^^$$#
  */
}