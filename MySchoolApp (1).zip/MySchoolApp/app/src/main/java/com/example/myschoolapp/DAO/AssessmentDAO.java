package com.example.myschoolapp.DAO;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Term;

import java.util.List;

/****
 *** @author Nicholas Walters
 **/

@Dao
public interface AssessmentDAO {


    /***
     ** 1. - update, insert, delete, get all tests
     */

    //delete
    @Delete
    void deleteTest(Assessment assessment);

    //update
    @Update
    void updateTest(Assessment assessment);

    //insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertTest(Assessment assessment);

    // get all tests
    @Query("SELECT * FROM assessments ORDER BY testID")
    List<Assessment> getAllAssessments();


}
