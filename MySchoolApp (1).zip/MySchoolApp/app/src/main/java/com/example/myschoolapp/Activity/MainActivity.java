package com.example.myschoolapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myschoolapp.Database.Repository;
import com.example.myschoolapp.R;
import com.example.myschoolapp.entities.Assessment;
import com.example.myschoolapp.entities.Course;
import com.example.myschoolapp.entities.Term;

/****
 *** @author Nicholas Walters
 **/
public class MainActivity extends AppCompatActivity {
    // static number from course page start date
    public static int numStartAlertCourse;

    // static number from course details page end date
    public static int numEndAlertCourse;

    // static number from test page start date
    public static int numStartAlertTest;

    // static number from test details page end date
    public static int numEndAlertTest;

    /**
     ** 7. - need test begin and end date alert as well
     */


    Button termsButHome, coursesButHome, testsButHome;
    TextView homePageText;

    // adding a repository
    Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /****
         *** Need this to go to the terms page
         **/
        //term button
        termsButHome = findViewById(R.id.termBtn);
        termsButHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToTermsPage = new Intent(MainActivity.this, Terms.class);

                Toast.makeText(MainActivity.this,
                        // test to make sure it go to the page
                        "Going to terms page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToTermsPage);

            }
        });


        // course button
        coursesButHome = findViewById(R.id.courseBtn);
        coursesButHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToCoursesPage = new Intent(MainActivity.this, Courses.class);
                Toast.makeText(MainActivity.this,
                        //test to make sure it goes to Courses page
                        "Going to courses page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToCoursesPage);
            }
        });

        // assessment button
        testsButHome = findViewById(R.id.testsBtn);
        testsButHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToTestsPage = new Intent(MainActivity.this, Assessments.class);
                Toast.makeText(MainActivity.this,
                        //test to make sure it goes to the Tests page
                        "Going to the tests page",
                        Toast.LENGTH_SHORT).show();
                startActivity(goToTestsPage);
            }
        });


    }

    /***
     ** 2. - checking to make sure the database will run from this screen
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.sampleTermTermDetMenuIt) {
            repository = new Repository(getApplication());


            /***
             ** 4. Add sample
             ** couple of terms
             */

            Term term = new Term(0, "Easy Term",
                    "October 1 2012", "December 25, 2017");
            repository.insertTerm(term);
            Term term1 = new Term(0, "Salamander Term",
                    "10/01/2023", "12/15/2023");
            repository.insertTerm(term1);

            Term term2 = new Term(0, "Marvel Term",
                    "Nov 24,2016", "Oct 21,2018");
            repository.insertTerm(term2);
            Term term3 = new Term(0, "Cooking Term",
                    "12/04/2011", "12/05/2011");
            repository.insertTerm(term3);
            Term term4 = new Term(0, "Next Term",
                    "10-01-2024", "10-02-2024");
            repository.insertTerm(term4);


            /***
             ** 5. add sample
             ** couple of courses
             ** moving this into course Details menu and commenting out
             */
            Course crs1 = new Course(0, "C1234", "October 23, 1995", "October 24, 1996",
                    "Agent Smith", "912-456-5644",
                    "mrAnderson@theMatrixisReal.com",
                    "is there a spoon", "completed", 1
            );
            repository.insertCourse(crs1);

            Course crs2 = new Course(0, "Math1060", "12/01/01",
                    "12/04/02", "Professor Proton",
                    "801-555-5555",
                    "mathisfun@profProton.com",
                    "dont invite sheldon",
                    "in progress",
                    1);
            repository.insertCourse(crs2);

            Course crs3 = new Course(0, "Jung2100", "01-10-2011",
                    "12-02-2021", "Baloo Bear", "444-444-4444",
                    "jungleBook@mansredflower.com", "I want to want like you",
                    "almost done", 1);
            repository.insertCourse(crs3);

            Course crs4 = new Course(0, "Greek-Mythology", "May 5 2015",
                    "July 6 2016", "Mr Zeus", "111-111-1111",
                    "bestGodfromTheCosmos@zeusisking@com", "love the lightning bolt",
                    "not started", 0);
            repository.insertCourse(crs4);

            Course crs5 = new Course(0, "Ways of the Hobbit", "04/03/2022",
                    "05/06/2022", "Ms. Bombadil",
                    "333-333-4444", "ringadongDillo@shire.uk",
                    "remember the first rain drop and acorn", "in progress", 0);
            repository.insertCourse(crs5);


            /***
             ** 6. add sample
             ** couple of Tests
             */
            Assessment ts1 = new Assessment(0, "Cooking Test", "Oct 13, 2025", "OCt 17, 2026", "Objective", 0);
            repository.insertTest(ts1);

            Assessment ts2 = new Assessment(0, "Fishing Exam", "11/01/01",
                    "11/02/03", "Performance Test", 1);
            repository.insertTest(ts2);

            Assessment ts3 = new Assessment(0, "Mario Jumping Final", "Oct 12, 2011",
                    "Oct 13, 2012", "Objective Test", 1);
            repository.insertTest(ts3);

            Assessment ts4 = new Assessment(0, "Wet Bandits Swiping", "December 24, 2023",
                    "December 25, 2023", " Performance Test", 4);
            repository.insertTest(ts4);

            Assessment ts5 = new Assessment(0, "C5445", "09/11/2022",
                    "09/12/2022", "Objective Test", 5);
            repository.insertTest(ts5);


            return true;
        }


        return true;
    }

    /****
     *** end of the line
     *** don't continue
     **/

     /*#^#^#^#^#^#^##^#^#^#^ REQUIREMENTS  ^#^#^#^#^#^#^#^#^#^#^#^#
    - main screen = home screen
    - need to make the buttons go to each Activity
    - Requirement B homescreen = activity_main


    ^##^#^#^#^#^#^#^#^#^##^^##^#^#^#^#^#^#^#^#^##^^##^#^#^#^#^#^#^#^#^#
  */
}